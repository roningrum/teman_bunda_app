import 'package:flutter/material.dart';

Color backgroundWhite = const Color(0xffFFF1FA);
Color pinkBold = const Color(0xffD9027D);